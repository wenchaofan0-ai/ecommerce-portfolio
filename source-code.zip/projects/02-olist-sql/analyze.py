"""Reproduce analysis with Python standard library and the original Olist CSVs.

Usage: python analyze.py --data /path/to/olist/csvs
"""
import argparse
import csv
import json
import sqlite3
from pathlib import Path

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data', type=Path, required=True)
    parser.add_argument('--out', type=Path, default=Path(__file__).parent / 'results')
    args = parser.parse_args()
    cfg = json.loads(Path(__file__).with_name('analysis_config.json').read_text(encoding='utf-8'))
    con = sqlite3.connect(':memory:')
    for table, ddl in cfg['schemas'].items():
        con.execute(ddl)
        with (args.data / cfg['files'][table]).open(encoding='utf-8-sig', newline='') as f:
            rows = csv.reader(f)
            columns = next(rows)
            sql = 'INSERT INTO ' + table + ' VALUES (' + ','.join('?' for _ in columns) + ')'
            con.executemany(sql, ([None if c == '' else c for c in row] for row in rows))
    for table, key in [('order_items', 'order_id'), ('reviews', 'order_id'),
                       ('order_items', 'product_id'), ('order_items', 'seller_id')]:
        con.execute(f'CREATE INDEX idx_{table}_{key} ON {table}({key})')
    con.executescript(cfg['views'])
    args.out.mkdir(parents=True, exist_ok=True)
    all_results = {}
    for key, query in cfg['queries'].items():
        cursor = con.execute(query)
        header = [d[0] for d in cursor.description]
        rows = cursor.fetchall()
        all_results[key] = [header] + [list(r) for r in rows]
        with (args.out / (key + '.csv')).open('w', encoding='utf-8-sig', newline='') as f:
            w = csv.writer(f)
            w.writerow(header)
            w.writerows(rows)
    # Independent checks against raw tables, not re-aggregation of the views.
    expected_count = con.execute("SELECT COUNT(*) FROM orders o WHERE order_status='delivered' AND EXISTS (SELECT 1 FROM order_items i WHERE i.order_id=o.order_id)").fetchone()[0]
    expected_amount = con.execute("SELECT ROUND(SUM(i.price),2) FROM order_items i JOIN orders o USING(order_id) WHERE o.order_status='delivered'").fetchone()[0]
    kpi = all_results['01_kpi_summary'][1]
    assert kpi[0] == expected_count
    assert abs(kpi[4] - expected_amount) < 0.01
    unknown_dates = con.execute('SELECT COUNT(*) FROM delivered_orders WHERE is_late IS NULL').fetchone()[0]
    known_reviews = con.execute('SELECT COUNT(*) FROM delivered_orders WHERE review_score IS NOT NULL AND is_late IS NOT NULL').fetchone()[0]
    assert sum(r[1] for r in all_results['05_delivery_vs_review'][1:]) == known_reviews
    validation = {'orders_reconciled': expected_count, 'gmv_reconciled': expected_amount,
                  'unknown_delivery_dates_excluded': unknown_dates,
                  'orders_in_delivery_rating_comparison': known_reviews,
                  'score_definition': 'Mean score per order, then mean across orders',
                  'low_score_definition': 'Order mean score <= 2',
                  'late_definition': 'Actual delivery timestamp > estimated delivery timestamp; missing timestamps excluded'}
    (args.out / 'validation.json').write_text(json.dumps(validation, ensure_ascii=False, indent=2), encoding='utf-8')
    (args.out / 'results.json').write_text(json.dumps(all_results, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'kpi': dict(zip(all_results['01_kpi_summary'][0],kpi)),
                      'delivery': all_results['05_delivery_vs_review'], 'validation': validation}, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()

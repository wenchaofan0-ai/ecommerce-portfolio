# 电商经营分析与SKU诊断作品集

本仓库整理三项个人学习作品：公开商品选品分析、Olist电商SQL经营分析、SKU经营诊断工具。作品使用AI辅助整理与实现，不代表企业内部项目或真实经营增长。

## 直接运行SKU诊断台

下载仓库后，双击 `docs/index.html`，用Chrome或Edge打开。无需安装依赖，无需API Key。

- 内置12个模拟SKU，可直接演示。
- 支持上传CSV、调整风险阈值、筛选SKU、导出分析结果。
- 数据只在当前浏览器中处理，不上传到服务器。
- CSV格式示例见 `docs/sample_sku_data.csv`。销量为近30天销量，退货率用百分数，例如8表示8%。

## 发布GitHub Pages

1. 把本文件夹里的内容上传到自己的GitHub仓库，保持 `docs` 目录结构。
2. 打开仓库的 Settings → Pages。
3. Source选择 Deploy from a branch，分支选 `main`，目录选 `/docs`，保存。
4. 等GitHub显示真实站点地址后，复制该地址放进简历。仓库源码地址与网页演示地址不是同一个地址。

也提供 `.github/workflows/pages.yml` 供选择GitHub Actions发布；二者选择一种即可。若使用工作流，请把Pages的Source切换为GitHub Actions。

## 目录

- `docs/`：可直接部署的SKU网页和CSV模板。
- `projects/01-product-selection/attachments/`：商品调研Excel和选品汇报PPT。
- `projects/02-olist-sql/`：可复现Python脚本、SQL、口径说明和结果。
- `projects/02-olist-sql/attachments/`：订单口径修正后的经营看板。

## 数据与口径

项目一是既有公开商品样本与模拟经营练习，页面价格不代表当前价格，评论数不等于销量，样本分布不代表市场需求。

项目二数据来自 [Olist公开数据集](https://www.kaggle.com/datasets/olistbr/brazilian-ecommerce)。原始数据不随仓库再分发，请从来源下载并遵守来源许可。金额单位为巴西雷亚尔，商品GMV不含运费。分析输出属于数据集的学习性衍生结果，保留来源归属；具体数据许可请以来源页面为准。

项目三全部内置SKU为模拟数据；输出的是规则诊断建议，未验证真实经营收益。

## 面试展示顺序

先展示选品汇报，再展示SQL分析的口径与结果，最后打开SKU工具演示上传、筛选和导出。说明个人实际贡献与AI辅助范围，不把学习项目描述成公司实习。

-- Item amounts; order-grain scores and rates; see README.

CREATE VIEW review_by_order AS
SELECT order_id, AVG(review_score) AS review_score
FROM reviews
GROUP BY order_id;

CREATE VIEW delivered_items AS
SELECT
    o.order_id,
    o.customer_id,
    c.customer_unique_id,
    o.order_purchase_timestamp,
    o.order_delivered_customer_date,
    o.order_estimated_delivery_date,
    oi.order_item_id,
    oi.product_id,
    oi.seller_id,
    oi.price,
    oi.freight_value,
    COALESCE(t.product_category_name_english, p.product_category_name, 'unknown') AS category,
    r.review_score,
    CASE
        WHEN o.order_delivered_customer_date IS NOT NULL
         AND o.order_estimated_delivery_date IS NOT NULL
         AND datetime(o.order_delivered_customer_date) > datetime(o.order_estimated_delivery_date)
        THEN 1 ELSE 0
    END AS is_late
FROM orders o
JOIN customers c ON c.customer_id = o.customer_id
JOIN order_items oi ON oi.order_id = o.order_id
LEFT JOIN products p ON p.product_id = oi.product_id
LEFT JOIN category_translation t ON t.product_category_name = p.product_category_name
LEFT JOIN review_by_order r ON r.order_id = o.order_id
WHERE o.order_status = 'delivered';

CREATE VIEW delivered_orders AS
SELECT order_id, customer_unique_id, order_purchase_timestamp,
 MAX(review_score) AS review_score, MAX(is_late) AS is_late,
 SUM(price) AS item_gmv, SUM(freight_value) AS freight_value
FROM delivered_items GROUP BY order_id;


-- 01_kpi_summary
SELECT COUNT(*) delivered_orders,
COUNT(DISTINCT customer_unique_id) unique_customers,
(SELECT COUNT(DISTINCT seller_id) FROM delivered_items) active_sellers,
(SELECT COUNT(DISTINCT product_id) FROM delivered_items) active_products,
ROUND(SUM(item_gmv),2) item_gmv, ROUND(AVG(item_gmv),2) item_aov,
ROUND(AVG(review_score),2) avg_review_score,
ROUND(100.0*AVG(is_late),2) late_delivery_rate_pct,
ROUND(100.0*SUM(freight_value)/SUM(item_gmv+freight_value),2) freight_share_pct
FROM delivered_orders;

-- 02_monthly_trend
SELECT substr(order_purchase_timestamp,1,7) order_month,
COUNT(*) orders, ROUND(SUM(item_gmv),2) item_gmv, ROUND(AVG(item_gmv),2) item_aov,
ROUND(AVG(review_score),2) avg_review_score, ROUND(100.0*AVG(is_late),2) late_delivery_rate_pct
FROM delivered_orders WHERE order_purchase_timestamp >= '2017-01-01' AND order_purchase_timestamp < '2018-09-01'
GROUP BY order_month ORDER BY order_month;

-- 03_category_performance

WITH experience AS (SELECT category,AVG(review_score) mean_score,100.0*AVG(is_late) late_pct FROM (SELECT DISTINCT category,order_id,review_score,is_late FROM delivered_items) GROUP BY category), category_base AS (
    SELECT
        category,
        COUNT(DISTINCT order_id) AS orders,
        COUNT(*) AS units,
        ROUND(SUM(price), 2) AS item_gmv,
        ROUND(SUM(price) / COUNT(DISTINCT order_id), 2) AS item_aov,
        ROUND(AVG(price), 2) AS avg_item_price,
        ROUND(MAX(e.mean_score), 2) AS avg_review_score,
        ROUND(MAX(e.late_pct), 2) AS late_delivery_rate_pct,
        ROUND(100.0 * SUM(freight_value) / SUM(price + freight_value), 2) AS freight_share_pct
    FROM delivered_items LEFT JOIN experience e USING(category)
    GROUP BY category
)
SELECT
    ROW_NUMBER() OVER (ORDER BY item_gmv DESC) AS gmv_rank,
    category,
    orders,
    units,
    item_gmv,
    item_aov,
    avg_item_price,
    avg_review_score,
    late_delivery_rate_pct,
    freight_share_pct,
    ROUND(100.0 * item_gmv / SUM(item_gmv) OVER (), 2) AS gmv_share_pct,
    ROUND(100.0 * SUM(item_gmv) OVER (
        ORDER BY item_gmv DESC
        ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    ) / SUM(item_gmv) OVER (), 2) AS cumulative_gmv_pct
FROM category_base
ORDER BY item_gmv DESC;
;

-- 04_seller_performance

WITH experience AS (SELECT seller_id,AVG(review_score) mean_score,100.0*AVG(is_late) late_pct FROM (SELECT DISTINCT seller_id,order_id,review_score,is_late FROM delivered_items) GROUP BY seller_id), seller_base AS (
    SELECT
        seller_id,
        COUNT(DISTINCT order_id) AS orders,
        COUNT(*) AS units,
        ROUND(SUM(price), 2) AS item_gmv,
        ROUND(SUM(price) / COUNT(DISTINCT order_id), 2) AS item_aov,
        ROUND(MAX(e.mean_score), 2) AS avg_review_score,
        ROUND(MAX(e.late_pct), 2) AS late_delivery_rate_pct
    FROM delivered_items LEFT JOIN experience e USING(seller_id)
    GROUP BY seller_id
)
SELECT
    ROW_NUMBER() OVER (ORDER BY item_gmv DESC) AS gmv_rank,
    seller_id,
    orders,
    units,
    item_gmv,
    item_aov,
    avg_review_score,
    late_delivery_rate_pct
FROM seller_base
WHERE orders >= 30
ORDER BY item_gmv DESC;
;

-- 05_delivery_vs_review
SELECT CASE WHEN is_late=1 THEN 'Late' ELSE 'On time' END delivery_status,
COUNT(*) orders, ROUND(AVG(review_score),2) avg_review_score,
ROUND(100.0*AVG(CASE WHEN review_score<=2 THEN 1.0 ELSE 0.0 END),2) low_rating_rate_pct
FROM delivered_orders WHERE review_score IS NOT NULL AND is_late IS NOT NULL
GROUP BY is_late ORDER BY is_late;

-- 06_price_band
WITH price_items AS (
SELECT *,CASE WHEN price<50 THEN '0-49' WHEN price<100 THEN '50-99' WHEN price<150 THEN '100-149' ELSE '150+' END price_band FROM delivered_items),
item_agg AS (SELECT price_band,COUNT(*) units,COUNT(DISTINCT order_id) orders,ROUND(SUM(price),2) item_gmv FROM price_items GROUP BY price_band),
order_agg AS (SELECT price_band,ROUND(AVG(review_score),2) avg_review_score,ROUND(100.0*AVG(is_late),2) late_delivery_rate_pct FROM (SELECT DISTINCT price_band,order_id,review_score,is_late FROM price_items) GROUP BY price_band)
SELECT a.*,b.avg_review_score,b.late_delivery_rate_pct FROM item_agg a JOIN order_agg b USING(price_band)
ORDER BY CASE a.price_band WHEN '0-49' THEN 1 WHEN '50-99' THEN 2 WHEN '100-149' THEN 3 ELSE 4 END;

-- 07_customer_frequency

WITH customer_orders AS (
    SELECT
        customer_unique_id,
        COUNT(DISTINCT order_id) AS order_count,
        ROUND(SUM(price), 2) AS item_gmv
    FROM delivered_items
    GROUP BY customer_unique_id
)
SELECT
    CASE WHEN order_count = 1 THEN 'One-time' ELSE 'Repeat' END AS customer_type,
    COUNT(*) AS customers,
    ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS customer_share_pct,
    ROUND(AVG(order_count), 2) AS avg_orders,
    ROUND(AVG(item_gmv), 2) AS avg_customer_gmv
FROM customer_orders
GROUP BY customer_type
ORDER BY customer_type;
;

-- 08_category_opportunity

WITH experience AS (SELECT category,AVG(review_score) mean_score,100.0*AVG(is_late) late_pct FROM (SELECT DISTINCT category,order_id,review_score,is_late FROM delivered_items) GROUP BY category), category_base AS (
    SELECT
        category,
        COUNT(DISTINCT order_id) AS orders,
        ROUND(SUM(price), 2) AS item_gmv,
        ROUND(MAX(e.mean_score), 2) AS avg_review_score,
        ROUND(MAX(e.late_pct), 2) AS late_delivery_rate_pct,
        ROUND(100.0 * SUM(freight_value) / SUM(price + freight_value), 2) AS freight_share_pct
    FROM delivered_items LEFT JOIN experience e USING(category)
    GROUP BY category
)
SELECT
    category,
    orders,
    item_gmv,
    avg_review_score,
    late_delivery_rate_pct,
    freight_share_pct,
    CASE
        WHEN item_gmv >= (SELECT AVG(item_gmv) FROM category_base)
         AND (avg_review_score < 4.0 OR late_delivery_rate_pct > 10)
        THEN 'High GMV / experience risk'
        WHEN item_gmv >= (SELECT AVG(item_gmv) FROM category_base)
         AND avg_review_score >= 4.0
         AND late_delivery_rate_pct <= 10
        THEN 'Core growth category'
        ELSE 'Observe'
    END AS opportunity_tag
FROM category_base
ORDER BY item_gmv DESC;
;